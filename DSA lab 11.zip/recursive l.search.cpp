#include <iostream>
using namespace std;

int linearSearch(const int arr[], int size, int target, int index = 0) {

    if (index >= size) {
        return -1;
    }


    if (arr[index] == target) {
        return index; 
    }

    return linearSearch(arr, size, target, index + 1);
}

int main() {
    
    const int arr[] = {4, 2, 7, 1, 3, 9, 5};
    int size = sizeof(arr) / sizeof(arr[0]);

    int target;
    cout << "Enter the number to search: ";
    cin >> target;

    
    int result = linearSearch(arr, size, target);

   
    if (result != -1) {
      cout << "Element found at index: " << result << endl;
    } else {
       cout << "Element not found in the array." <<endl;
    }

    return 0;
}
