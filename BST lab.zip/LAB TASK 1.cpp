#include <iostream>
using namespace std;

class Node {
public:
    int key;
    Node* left;
    Node* right;

    Node(int value) : key(value), left(NULL), right(NULL) {}
};

class BinarySearchTree {
private:
    Node* root;

    Node* insert(Node* node, int key) {
        if (node == NULL) {
            return new Node(key);
        }
        if (key < node->key) {
            node->left = insert(node->left, key);
        } else if (key > node->key) {
            node->right = insert(node->right, key);
        }
        return node;
    }

    void inorder(Node* node) {
        if (node != NULL) {
            inorder(node->left);
            cout << node->key << " ";
            inorder(node->right);
        }
    }

    void preorder(Node* node) {
        if (node != NULL) {
            cout << node->key << " ";
            preorder(node->left);
            preorder(node->right);
        }
    }

    void postorder(Node* node) {
        if (node != NULL) {
            postorder(node->left);
            postorder(node->right);
            cout << node->key << " ";
        }
    }

public:
    BinarySearchTree() : root(NULL) {}

    void insert(int key) {
        root = insert(root, key);
    }

    void inorder() {
        inorder(root);
        cout << endl;
    }

    void preorder() {
        preorder(root);
        cout << endl;
    }

    void postorder() {
        postorder(root);
        cout << endl;
    }
};

int main() {
    BinarySearchTree bst;
    int values[] = {12, 7, 9, 10, 22, 24, 30, 18, 3, 14, 20};

    for (int value : values) {
        bst.insert(value);
    }

    cout << "In-order traversal: ";
    bst.inorder();

    cout << "Pre-order traversal: ";
    bst.preorder();

    cout << "Post-order traversal: ";
    bst.postorder();

    return 0;
}



