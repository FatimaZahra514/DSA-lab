#include <iostream>
using namespace std;

class EmployeeNode {
public:
    int empNumber;
    string name;
    double salary;
    EmployeeNode* left;
    EmployeeNode* right;

    EmployeeNode(int number, string empName, double empSalary) 
        : empNumber(number), name(empName), salary(empSalary), left(NULL), right(NULL) {}
    
    void preorder(EmployeeNode* node) {
        if (node != NULL) {
            cout << "Employee Number: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
            preorder(node->left);
            preorder(node->right);
        }
    }

    void inorder(EmployeeNode* node) {
        if (node != NULL) {
            inorder(node->left);
            cout << "Employee Number: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
            inorder(node->right);
        }
    }

    void postorder(EmployeeNode* node) {
        if (node != NULL) {
            postorder(node->left);
            postorder(node->right);
            cout << "Employee Number: " << node->empNumber << ", Name: " << node->name << ", Salary: " << node->salary << endl;
        }
    }
};

class EmployeeBST {
private:
    EmployeeNode* root;

    EmployeeNode* insert(EmployeeNode* node, int empNumber, string name, double salary) {
        if (node == NULL) {
            return new EmployeeNode(empNumber, name, salary);
        }
        if (empNumber < node->empNumber) {
            node->left = insert(node->left, empNumber, name, salary);
        } else if (empNumber > node->empNumber) {
            node->right = insert(node->right, empNumber, name, salary);
        }
        return node;
    }

    EmployeeNode* search(EmployeeNode* node, int empNumber) {
        if (node == NULL || node->empNumber == empNumber) {
            return node;
        }
        if (empNumber < node->empNumber) {
            return search(node->left, empNumber);
        }
        return search(node->right, empNumber);
    }

    EmployeeNode* deleteEmployee(EmployeeNode* node, int empNumber) {
       
        if (node == NULL) return node;
        if (empNumber < node->empNumber) {
            node->left = deleteEmployee(node->left, empNumber);
        } else if (empNumber > node->empNumber) {
            node->right = deleteEmployee(node->right, empNumber);
        } else {
            if (node->left == NULL) {
                EmployeeNode* temp = node->right;
                delete node;
                return temp;
            } else if (node->right == NULL) {
                EmployeeNode* temp = node->left;
                delete node;
                return temp;
            }

            EmployeeNode* temp = findMin(node->right);
            node->empNumber = temp->empNumber;
            node->name = temp->name;
            node->salary = temp->salary;
            node->right = deleteEmployee(node->right, temp->empNumber);
        }
        return node;
    }

    EmployeeNode* findMin(EmployeeNode* node) {
        while (node->left != NULL) {
            node = node->left;
        }
        return node;
    }

public:
    EmployeeBST() : root(NULL) {}

    void insert(int empNumber, string name, double salary) {
        root = insert(root, empNumber, name, salary);
    }

    void search(int empNumber) {
        EmployeeNode* result = search(root, empNumber);
        if (result != NULL) {
            cout << "Employee Found - Number: " << result->empNumber << ", Name: " << result->name << ", Salary: " << result->salary << endl;
        } else {
            cout << "Employee with Number " << empNumber << " not found." << endl;
        }
    }

    void deleteEmployee(int empNumber) {
        root = deleteEmployee(root, empNumber);
    }

    void inorder() {
        cout << "\nIn-order Traversal:" << endl;
        root->inorder(root);
    }

    void preorder() {
        cout << "\nPre-order Traversal:" << endl;
        root->preorder(root);
    }

    void postorder() {
        cout << "\nPost-order Traversal:" << endl;
        root->postorder(root);
    }
};

int main() {
    EmployeeBST bst;

    bst.insert(101, "Danny", 60000);
    bst.insert(102, "Alisha", 55000);
    bst.insert(103, "Charlie", 75000);
    bst.insert(104, "Parisa", 50000);
    bst.insert(105, "Maham", 70000);
    
    bst.inorder();
    bst.preorder();
    bst.postorder();
    cout<<"  "<<endl;
    bst.search(103);
    bst.deleteEmployee(102);
    bst.inorder();

    return 0;
}

